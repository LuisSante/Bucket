#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include<iostream>

using namespace std;

template<class T>
class List{
  private:
  class Node{
    public:
      T data;
      Node* next;

      Node(){
        data = 0;
        next = nullptr;
      }
      Node(T element){
        data = element;
        next = nullptr;
      }
  };
	int size;
	Node* head;
	public:	
    List(){
      size = 0;
      head = nullptr;
    }

	void insert(T new_element,int pos){
      Node* node = new Node(new_element);
      Node* aux = head;
      Node* aux2=nullptr;

      if(head == nullptr){
        head = node;
        size++;
      }else{
        if(size == 0){
          node->next = head ;
          head = node;
          size++;
        }
        else if (pos>1 && pos<size+1){
          for(int  i=1 ; i<pos ; i++){
            aux2 = aux;//hace que aux2 este detras de aux
            aux = aux->next;//mantenga al nodo creado en el medio
          }
          aux2->next = node;
          node->next = aux;
          size++;
        }
        else if(pos>size){
          while(aux -> next != nullptr){
            aux = aux -> next;
          }
          aux -> next = node;
          size++;
        }
      }
    }

    void remove(int pos){
      Node* aux = head;
      Node* aux2 = aux -> next;

      if(pos<1 || pos >size){
        cout<<"fuera de rango"<<endl;
      }else if(pos == 1){
        head = head -> next;
        delete(aux);
      }else{
        for(int i=2 ; i<= pos ;i++){
          if(i==pos){
            Node* temp = aux2;
            aux -> next = aux2 -> next;
            delete temp;
            size--;
          }
          aux = aux -> next;
          aux2 = aux2 -> next;
        }
      }
    }

    void search(int new_element){
      Node* aux = head;
      int cont=0;

      while(aux != nullptr){
        if(aux -> data = new_element){
            break;
        }
        aux = aux -> next;
        cont++;
      }
      cout<<"la posicion en la que se encuentra es"<<cont<<endl;

      if(cont == 0){
        cout<<"no existe el dato"<<endl;
      }
    } 
    
    void print()
    {
      Node* aux = head;
      while(aux != nullptr){
          cout<<aux-> data<<" ";
          aux = aux -> next;
      }
    }
};

#endif