#include "listdoublecircle.h"

int main(){

    ListCircle<int> l1;
    l1.insert(10,0);
    return 0;
}