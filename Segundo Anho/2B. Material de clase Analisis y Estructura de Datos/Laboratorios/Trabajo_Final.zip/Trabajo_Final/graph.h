#ifndef GRAPH_H
#define GRAPH_H
#include<iostream>
#include<string.h>
#include "cola.h"

using namespace std;

template<class T>
class Edge;

template<class T>
class Node{
    private:
        T data;
        Node<T>* next;
        Edge<T>* adj;

    public:
        Node() = default;

        Node(T data){
            this -> data = data;
            this -> adj = nullptr;
            this -> next = nullptr;
        }

        template<class U> friend class Graph;
};

template<class T>
class Edge{
    private:
        int weight;
        Node<T>* adj;
        Edge* next;
    
    public:
        Edge(T weight){
            this -> weight = weight;
            this -> adj = nullptr;
            this -> next = nullptr;
        }
        template<class U> friend class Graph;
};
    
template<class T>
class Graph{
    private:
        Node<T>* start;
        int num_node;
    public:
        Graph(){
            start = nullptr;
            num_node = 0;
        }

        int size(){
            Node<T>* aux = start;
            int count=0;

            while(aux != nullptr){
                
                count++;
                aux = aux -> next;
            }

            return count;
        }

        bool is_Empty(){            
            if(start == nullptr){
                return true;
            }
            return false;
        }

        Node<T>* getNode(const T new_data){
            Node<T>* aux = start;

            while(aux){
                
                if(aux -> data == new_data){

                    return aux;
                }
                aux = aux -> next;
            }

            return nullptr;
        }

        void insert_node(T new_data){
            Node<T>* new_node = new Node<T>(new_data);
            Node<T>* aux = start;

            if(start == nullptr){
                start = new_node;
            }

            else{
                while(aux -> next != nullptr){
                    aux = aux -> next;
                }
                aux -> next = new_node;               
            }
            num_node++;
        }

        void print(){
            Node<T>* aux = start;
            while(aux){
                cout << aux -> data << " ";
                aux = aux -> next;
            }
            cout<<endl;
        }

        void insert_edge(Node<T>* origin , Node<T>* end , int new_weight){
            Edge<T>* new_edge = new Edge<T>(new_weight);
            Edge<T>* aux = origin -> adj;

            if(aux == nullptr){
                origin -> adj = new_edge;
                new_edge -> adj = end;
            }

            else{
                while(aux -> next != nullptr){
                    aux = aux -> next;
                }
                aux -> next = new_edge;
                new_edge -> adj = end;
            }
        }

        void list_adj(){
            Node<T>* node_aux = start;
            Edge<T>* edge_aux = nullptr;

            while(node_aux != nullptr){

                cout<<node_aux -> data <<"->";
                edge_aux = node_aux -> adj;

                while(edge_aux != nullptr){
                    cout<<edge_aux -> adj -> data<<"->";
                    edge_aux = edge_aux -> next;
                }
                node_aux = node_aux -> next;
                cout<<endl;
            }
        }
};

#endif
