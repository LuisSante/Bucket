#include<iostream>
#include<cstdlib>
#include<fstream>
#include<string>
#include<vector>
#include "graph.h"

using namespace std;

int main(){
    Graph<int> g;
    ifstream archivo_entrada("entrada.txt");

    string linea;
    string palabra;
    int num;
    int p=0;

    while(getline(archivo_entrada, linea)){
        palabra = linea;
        p++;
        if(p==1){
            num = atoi(linea.c_str());
            for(int i=1 ; i <= num ; i++){
                g.insert_node(i);
            }
        }

        if(p>=4){
            int a = 0 , b = 0, cont = 0;
            int n1 = 0 , n2 = 0 , n3=0;
            for(int i=0 ; palabra[i] != '\0' ; i++){
                if(palabra[i] == ' '){
                    cont++;
                    if(cont == 1){
                        a = i;
                    }

                    if(cont == 2){
                        b = i;
                    }
                }
            }
            n1 = atoi((palabra.substr(0,a)).c_str());
            n2 = atoi((palabra.substr(a+1,b-1)).c_str());
            n3 = atoi((palabra.substr(b+1,palabra.length())).c_str());
            g.insert_edge(g.getNode(n1),g.getNode(n2),n3);
            g.insert_edge(g.getNode(n2),g.getNode(n1),n3);
        }
    }
    return 0;
}
