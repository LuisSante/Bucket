#ifndef COLA_H
#define COLA_h

#include<iostream>
#include<string>

using namespace std;

template<class T>
class NodeQ{
    private:
        T data;
        int priori;
        NodeQ* next;
    public:
        NodeQ()=default;

        NodeQ(T data, int priori){
            this -> data = data;
            this -> priori = priori;
            this -> next = nullptr;
        }

        template<class U> friend class Queue;
};

template<class T>
class Queue{
    private:
        NodeQ<T>* head;

    public:
        Queue(){
            head = nullptr;
        }

        bool isEmpty(){
            NodeQ<T>* aux = head;
            if(aux == nullptr){
                return true;
            }
            return false;
        }

        int size(){
            NodeQ<T>* aux = head;
            int count = 0;

            while(aux != nullptr){
                count++;
                aux = aux -> next ;
            }

            return count;
        }

        void insert(T new_data, int new_priori){

            NodeQ<T>* aux = head;
            NodeQ<T>* new_node = new NodeQ<T>(new_data,new_priori);

            if(head == nullptr){
                head = new_node;
            }

            else{
                while(aux -> next != nullptr){
                    aux = aux -> next;
                }

                aux -> next = new_node;
            }
        }

        void sort_priori(){
            NodeQ<T>* aux = head;

            int temp;
            T temp2;

            while(aux -> next != nullptr){

                NodeQ<T>* aux2 = aux -> next;

                while(aux2 != nullptr){
                    if(aux -> priori > aux2 -> priori){
                        temp = aux -> priori;
                        temp2 = aux -> data;

                        aux -> priori = aux2 -> priori;
                        aux -> data = aux2 -> data;

                        aux2 -> priori  = temp;
                        aux2 -> data = temp2;
                    }
                    aux2 = aux2 -> next;
                }
                aux = aux -> next;
            }
        }

        void queue_priori(T new_data, int new_priori){
            insert(new_data,new_priori);
            sort_priori();
        }

        void delete_node(){
            NodeQ<T>* aux = head;

            if(head == nullptr){
                return ;
            }

            else{
                head = aux -> next;
                delete aux;
                aux = aux -> next;
            }
        }

        void print(){
            NodeQ<T>* aux = head;

            cout<<"COLA DE PRIORIDAD"<<endl;
            while(aux){
                cout<<"["<<aux -> data <<"|"<<aux->priori<<"]";
                aux = aux -> next;
            }
            cout<<endl;
        }
};

#endif