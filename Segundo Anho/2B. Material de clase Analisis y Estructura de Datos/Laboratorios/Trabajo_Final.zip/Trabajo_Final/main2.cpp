#include<iostream>
#include "cola.h"

using namespace std;

int main(){

    Queue<int> q;
    q.queue_priori(2,3);
    q.queue_priori(3,1);
    q.queue_priori(4,9);
    q.queue_priori(5,4);
    q.print();
    q.delete_node();
    q.print();
    return 0;
}
